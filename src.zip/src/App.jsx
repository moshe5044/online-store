import './style/App.css';
import Layout from './Layout';

function App() {

  return (
    <div className='app'>
      <Layout />
    </div>
  )
}

export default App
