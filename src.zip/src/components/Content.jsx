import React from 'react'
import ItemList from './ItemList'

function Content() {

  return (
    <div className='content'>
        <ItemList />
    </div>
  )
}

export default Content